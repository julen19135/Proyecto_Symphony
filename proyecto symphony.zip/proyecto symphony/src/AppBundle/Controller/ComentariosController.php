<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Comentarios;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;use Symfony\Component\HttpFoundation\Request;

/**
 * Comentario controller.
 *
 * @Route("comentarios")
 */
class ComentariosController extends Controller
{
    /**
     * Lists all comentario entities.
     *
     * @Route("/", name="comentarios_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $comentarios = $em->getRepository('AppBundle:Comentarios')->findAll();

        return $this->render('comentarios/index.html.twig', array(
            'comentarios' => $comentarios,
        ));
    }

    /**
     * Creates a new comentario entity.
     *
     * @Route("/new", name="comentarios_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
        $comentario = new Comentarios();
        $form = $this->createForm('AppBundle\Form\ComentariosType', $comentario);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($comentario);
            $em->flush();

            return $this->redirectToRoute('comentarios_show', array('id' => $comentario->getId()));
        }

        return $this->render('comentarios/new.html.twig', array(
            'comentario' => $comentario,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a comentario entity.
     *
     * @Route("/{id}", name="comentarios_show")
     * @Method("GET")
     */
    public function showAction(Comentarios $comentario)
    {
        $deleteForm = $this->createDeleteForm($comentario);

        return $this->render('comentarios/show.html.twig', array(
            'comentario' => $comentario,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing comentario entity.
     *
     * @Route("/{id}/edit", name="comentarios_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, Comentarios $comentario)
    {
        $deleteForm = $this->createDeleteForm($comentario);
        $editForm = $this->createForm('AppBundle\Form\ComentariosType', $comentario);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('comentarios_edit', array('id' => $comentario->getId()));
        }

        return $this->render('comentarios/edit.html.twig', array(
            'comentario' => $comentario,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a comentario entity.
     *
     * @Route("/{id}", name="comentarios_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Comentarios $comentario)
    {
        $form = $this->createDeleteForm($comentario);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($comentario);
            $em->flush();
        }

        return $this->redirectToRoute('comentarios_index');
    }

    /**
     * Creates a form to delete a comentario entity.
     *
     * @param Comentarios $comentario The comentario entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Comentarios $comentario)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('comentarios_delete', array('id' => $comentario->getId())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
